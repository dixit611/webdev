document.addEventListener('DOMContentLoaded' ,function(){
  let typed= new Typed('#typing',{
    strings: [
        '  ',
        'Frontend Developr',
        'Engineer',
        'Full Stack Java Developer',
      ],
    typeSpeed:100,
    BackSpeed:100,
    BackDelay:1000,
    loop:true
  });

});