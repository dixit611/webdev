                    // toggle style switcher
const styleSwitcherToggle =document.querySelector(".style-switcher-toggler");
styleSwitcherToggle.addEventListener("click", () => {
    document.querySelector(".style-switcher").classList.toggle("open");
})
// hide style switcher on scroll
window.addEventListener("scroll", () =>{
    if(document.querySelector(".style-switcher").classList.contains("open"))
    {
        document.querySelector(".style-switcher").classList.remove("open");
    }
})
//                             themes colors
const alternateStyles =document.querySelectorAll(".alternate-style");
function setActiveStyle(color)
{
    alternateStyles.forEach((style) =>{
        if(color === style.getAttribute("title"))
        {
            style.removeAttribute("disabled");
        }
        else
        {
            style.setAttribute("disabled","true");
        }
    }) 
}

     //              theme light and dark mode

// const dayNight =document.querySelector(".day-night");
// dayNight.addEventListener("click", () => {
//     dayNight.querySelector("i").classList.toggle("fa-sun");
//     dayNight.querySelector("i").classList.toggle("fa-moon");
//     document.body.classList.toggle("dark");
// })
// window.addEventListener("load",() => {
//     if(document.body.classList.contains("dark"))
//     {
//         dayNight.querySelector("i").classList.add("fa-sun");
//     }
//     else
//     {
//         dayNight.querySelector("i").classList.add("fa-moon");
//     }
// })



const dayNight = document.querySelector(".day-night");

// Function to set initial dark mode
function setDarkMode() {
    document.body.classList.add("dark");
    dayNight.querySelector("i").classList.add("fa-moon");
}

// Toggle function for day/night mode
function toggleDayNight() {
    document.body.classList.toggle("dark");
    dayNight.querySelector("i").classList.toggle("fa-moon");
    dayNight.querySelector("i").classList.toggle("fa-sun");
}

// Set initial mode on page load
window.addEventListener("load", () => {
    setDarkMode(); // Start with dark mode
});

// Toggle mode on click
dayNight.addEventListener("click", toggleDayNight);











// message code


// Wait for the DOM to fully load
document.addEventListener('DOMContentLoaded', function() {
    // Find the contact form element
    const contactForm = document.getElementById('contactForm');
    
    // Add event listener for form submission
    contactForm.addEventListener('submit', function(event) {
        // Prevent the default form submission behavior
        event.preventDefault();

        // Get form input values
        const name = document.getElementById('name').value;
        const email = document.getElementById('email').value;
        const subject = document.getElementById('subject').value;
        const message = document.getElementById('message').value;

        // Here you can perform additional validation if needed

        // Send the message (simulated in this example)
        sendMessage(name, email, subject, message);
    });
});

// Function to simulate sending a message
function sendMessage(name, email, subject, message) {
    // You can replace this with actual code to send the message via API or backend
    
    // For demonstration purposes, log the message to the console
    console.log('Message sent:');
    console.log('Name:', name);
    console.log('Email:', email);
    console.log('Subject:', subject);
    console.log('Message:', message);

    // Display a confirmation message (you can modify this as needed)
    alert('Message sent successfully!'); // Replace with your own UI/UX feedback
}


// portfolio

function showAllProjects() {
    // Show all portfolio items
    var allProjects = document.querySelectorAll('.portfolio-item');
    allProjects.forEach(function(project) {
        project.style.display = 'block';
    });
}

function showMinorProjects() {
    // Hide all major projects
    var majorProjects = document.querySelectorAll('.major-project');
    majorProjects.forEach(function(project) {
        project.style.display = 'none';
    });

    // Show all minor projects
    var minorProjects = document.querySelectorAll('[data-category="minor"]');
    minorProjects.forEach(function(project) {
        project.style.display = 'block';
    });
}

function showMajorProjects() {
    // Hide all minor projects
    var minorProjects = document.querySelectorAll('[data-category="minor"]');
    minorProjects.forEach(function(project) {
        project.style.display = 'none';
    });

    // Show all major projects
    var majorProjects = document.querySelectorAll('.major-project');
    majorProjects.forEach(function(project) {
        project.style.display = 'block';
    });
}











// side effect


// JavaScript for toggling sidebar visibility
function toggleSidebar() {
    var aside = document.querySelector('.aside');
    aside.classList.toggle('show');
}

// side effect 



// document.addEventListener('DOMContentLoaded', function() {
//     const navToggler = document.getElementById('navToggler');
//     const aside = document.querySelector('.aside');
  
//     // Add click event listener to the navigation toggler
//     navToggler.addEventListener('click', function() {
//         // Toggle the 'show' class on the sidebar to display/hide it
//         aside.classList.toggle('show');
//     });
  
//     // Optional: Close sidebar when clicking outside of it
//     document.addEventListener('click', function(event) {
//         const target = event.target;
//         const isNavToggler = target === navToggler || navToggler.contains(target);
//         const isAside = target === aside || aside.contains(target);
  
//         if (!isNavToggler && !isAside) {
//             aside.classList.remove('show');
//         }
//     });
//   });
  