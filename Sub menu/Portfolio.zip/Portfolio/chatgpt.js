document.addEventListener('DOMContentLoaded', function() {
  const MinerProject = document.getElementById('MinerProject');
  const MajorProject = document.getElementById('MajorProject');

  // Function to show minor projects and hide major projects
  MinerProject.addEventListener('click', function() {
      toggleProjects('minorProjects', 'majorProjects');
  });

  // Function to show major projects and hide minor projects
  MajorProjectProject.addEventListener('click', function() {
      toggleProjects('majorProjects', 'minorProjects');
  });

  function toggleProjects(showId, hideId) {
      const showProjects = document.querySelectorAll(`#${showId} .portfolio-item`);
      const hideProjects = document.querySelectorAll(`#${hideId} .portfolio-item`);

      // Show projects in the showId container
      showProjects.forEach(function(item) {
          item.classList.add('active');
      });

      // Hide projects in the hideId container
      hideProjects.forEach(function(item) {
          item.classList.remove('active');
      });
  }
});


let isSelected = false;

function toggleSelection() {
  isSelected = !isSelected;
  const button = document.getElementById('major-project-button');
  if (isSelected) {
    button.classList.add('selected');
  } else {
    button.classList.remove('selected');
  }
}








//side effect 



